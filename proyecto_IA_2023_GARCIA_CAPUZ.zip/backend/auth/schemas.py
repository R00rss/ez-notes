# from ..schemas import General_Response_Model

# class Login_Response(General_Response_Model):
#     status: Status
#     message: str
#     error: str | None
#     payload: any | None
