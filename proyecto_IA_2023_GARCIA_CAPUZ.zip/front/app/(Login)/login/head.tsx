export default function Head() {
  return (
    <>
      <title>Login</title>
    </>
  );
}
