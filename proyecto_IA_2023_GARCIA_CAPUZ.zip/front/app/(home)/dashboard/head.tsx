export default function Head() {
  return (
    <>
      <title>dashboard</title>
    </>
  )
}
