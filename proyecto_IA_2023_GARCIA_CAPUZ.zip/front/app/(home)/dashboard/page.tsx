export default function page() {
  return <div>dashboard</div>;
}
