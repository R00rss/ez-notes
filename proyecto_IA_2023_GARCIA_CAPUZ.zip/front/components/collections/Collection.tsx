export default function Collection() {
  return <div>Note</div>;
}
