export default function Card() {
  return <div>card</div>;
}
