import { Collection } from "./collection";

export interface ItemCollection extends Collection {
//   selected: boolean;
}
